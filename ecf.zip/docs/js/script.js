function init_menu() {
  const $js_header_menu_toggle = $(".js_header_menu_toggle"),
    $main_nav = $(".main-nav");

  $js_header_menu_toggle.on("click", function () {
    $(".bar").toggleClass("animate");
    $main_nav.toggleClass("open");
    $(".header, body").toggleClass("modal-open");
    $(document).on("click", document_click_handler);
  });

  function document_click_handler(evt) {
    if (
      !$(evt.target).is(".main-nav") &&
      !$(evt.target).closest(".js_header_menu_toggle").length &&
      !$(evt.target).is(".js_header_menu_toggle")
    ) {
      $main_nav.removeClass("open");
      $(".bar").removeClass("animate");
      $(".header, body").removeClass("modal-open");
      $(document).off("click", document_click_handler);
    }
  }
}

function init_carousel() {
  $(".js_banks_carousel").slick({
    dots: true,
    infinite: true,
    prevArrow: $(".banks__nav--prev"),
    nextArrow: $(".banks__nav--next"),
    appendDots: $(".banks__slider-wrap"),
    slidesToShow: 5,
    slidesToScroll: 5,

    responsive: [
      {
        breakpoint: 1300,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
        },
      },
      {
        breakpoint: 800,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        },
      },
      // You can unslick at a given breakpoint now by adding:
      // settings: "unslick"
      // instead of a settings object
    ],
  });
}

function init_contact_form() {
  const $callback_form = $(".callback__form");

  $('input[name="phone"]').on("keydown", function (evt) {
    if ($(this).val() == "" && evt.originalEvent.key == "8") {
      evt.preventDefault();

      $(this).val("+7 ");
    }

    $(this).mask("+7 000 000-00-00");
  });

  $contact_form.each(function () {
    const $form = $(this);
    $form.validate({
      rules: {
        name: "required",
        email: {
          required: true,
          email: true,
        },
        phone: "required",
        "card-number": "required",
        "card-expiry-date": "required",
        cvc: "required",
        "callback-message": "required",
      },
      messages: {
        name: "Введите ваше имя",
        email: {
          required: "Введите адрес электронной почты",
          email: "Введите почту, в формате х@x.xx",
        },
        phone: "Введите ваш телефон",
        "card-number": "Введите номер карты",
        "card-expiry-date": "Введите срок действия карты",
        cvc: "Введите CVV/CVC код",
        "callback-message": "Введите комментарий",
      },
      submitHandler: function (form) {
        form.submit();
      },
    });
  });
}

$(document).ready(function () {
  init_menu();
  init_carousel();
  init_contact_form();
});
